# MEC Deployment with control-plane version

## This is all about MEC deployment
- Modify UE_SUBNET's IP, which matches the IP of gtp0 in your EPC
